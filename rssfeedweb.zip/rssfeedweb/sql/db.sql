CREATE SCHEMA rss;
USE rss;

CREATE TABLE property
(
id int NOT NULL AUTO_INCREMENT,
address varchar(255),
price int,
beds int,
type varchar(100),
rss varchar(100),
PRIMARY KEY (id)
);