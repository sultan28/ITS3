package model;

import java.io.Serializable;

public class Property implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private long id;
	private String rss;
    private String address;
    private String type;
    private long price;
    private long beds;
    
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the price
	 */
	public long getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(long price) {
		this.price = price;
	}
	/**
	 * @return the beds
	 */
	public long getBeds() {
		return beds;
	}
	/**
	 * @param beds the beds to set
	 */
	public void setBeds(long beds) {
		this.beds = beds;
	}
	/**
	 * @return the rss
	 */
	public String getRss() {
		return rss;
	}
	/**
	 * @param rss the rss to set
	 */
	public void setRss(String rss) {
		this.rss = rss;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
    
}
