package dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import model.Property;

public class PropertyDAO {
    public static List<Property> getAlls(){
    	Session session = null;
    	SessionFactory factory = null;
    	List<Property> list = null;
        try {
        	Configuration configuration = new Configuration();
            configuration.configure();
            ServiceRegistry  serviceRegistry = new ServiceRegistryBuilder().applySettings(
                    configuration.getProperties()). buildServiceRegistry();
            factory = configuration.buildSessionFactory(serviceRegistry);
        	session = factory.openSession();
        	System.out.println("Connected: " + session.isConnected());
        	Query qry = session.createQuery("from Property p order by p.price");
    		list = qry.list();
    		System.out.println("Total Number Of Records : "+ list.size());
        } catch (Exception ex) {
        	if (session!=null){ 
        		session.close();
        	}
        	if (factory!=null){ 
        		factory.close();
        	}
            throw ex;
        } finally {
            session.close();
            factory.close();
        }
        return list;
    } 

}
