package servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.PropertyDAO;
import model.Property;

@WebServlet(value="/process")
public class PropertyServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final Pattern pattern = Pattern.compile("<item>(.+?)</item>");
	
	private static final String DAFT_URL= "http://www.daft.ie/rss.daft?uid=1402060&id=676311&xk=741154";
	private static final String MYHOME_URL = "http://www.myhome.ie/rentals/mayo/property-to-rent-in-castlebar?&format=rss";
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        try {
        	processDaft();
        	processMyHome();
            response.sendRedirect("success.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	private void processDaft(){
		try{
			String content = readRssContent(DAFT_URL);
			Matcher matcher = pattern.matcher(content);
		    while (matcher.find()) {
		    	String type = "weekly";
		    	String item = matcher.group(1);
		    	String address = getTagValueForDaft(item, "address", true).trim();
		    	String priceStr = getTagValueForDaft(item, "price", true);
		    	if(priceStr.contains("monthly")){
		    		priceStr = priceStr.replace("monthly",  "").trim();
		    		type = "monthly";
		    	}else{
		    		priceStr = priceStr.replace("weekly",  "").trim();
		    	}
		    	int price = Integer.parseInt(priceStr);
		    	int beds = Integer.parseInt(getTagValueForDaft(item, "bedrooms", false));
		    	System.out.println("address : " + address);
		        System.out.println("price : " + price);
		        System.out.println("beds: " + beds);
		        System.out.println("type: " + type);
		        System.out.println("----------DAFT-------");
		        addProperty(address, "DAFT", type, beds, price);
		    }
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	private void processMyHome(){
		try{
			String content = readRssContent(MYHOME_URL);
			Matcher matcher = pattern.matcher(content);
		    while (matcher.find()) {
		    	String item = matcher.group(1);
		    	String title = getTagValueForMyHome(item, "title");
		    	String[] arr = title.split("-");
		    	if(!title.equals("") && arr.length == 2){
		    		String type = "monthly";
		    		String address = arr[0].trim();
			    	int price = Integer.parseInt(arr[1].trim().replaceAll("[^0-9?!\\.]",""));
			    	String bedStr = getTagValueForMyHome(item, "bedrooms").trim();
			    	int beds = 1;
			    	System.out.println("bad beds " + bedStr);
			    	if(!bedStr.equals("")){
			    		beds = Integer.parseInt(bedStr.replace("Bed","").trim());
			    	}
			    	System.out.println("address : " + address);
			    	String priceStr = arr[1].trim();
			    	if(priceStr.contains("weekly")){
			    		type = "weekly";
			    	}
			        System.out.println("price : " + price);
			        System.out.println("beds: " + beds);
			        System.out.println("type: " + type);
			        System.out.println("----------MYHOME-------");
			        addProperty(address, "MYHOME", type, beds, price);
		    	}
		    }
		}catch(IOException e){
			e.printStackTrace();
		}
	} 
	
	private void addProperty(String address, String rss, String type, int beds, int price){
		Property property = new Property();
    	property.setAddress(address);
    	property.setBeds(beds);
    	property.setPrice(price);
    	property.setRss(rss);
    	property.setType(type);
    	PropertyDAO.addProperty(property);
	}
	
	private String readRssContent(String url) throws IOException{
		String result = "";
		URL rssUrl = new URL(url);
		BufferedReader br = new BufferedReader(new InputStreamReader(rssUrl.openStream()));
		String line;
		while((line = br.readLine()) != null) {
			result += line + " ";
		}
		br.close();
		return result;
	}
	
	private String getTagValueForDaft(String line, String tagName, boolean isDataTag){
		String value = "" ;
		String startTag = isDataTag ? "<" + tagName + "><![CDATA[" : "<" + tagName + ">";
		String closeTag = isDataTag ? "]]></" + tagName + ">" : "</" + tagName + ">" ;
		if(line.contains(startTag)){
			int first = line.indexOf(startTag);
			value = line.substring(first);
			value = value.replace(startTag, "");
			int last = value.indexOf(closeTag);
			value = value.substring(0, last);
		}
		return value;
	}
	
	private String getTagValueForMyHome(String line, String tagName){
		String value = "" ;
		String startTag = "<" + tagName + ">";
		String closeTag = "</" + tagName + ">";
		if(line.contains(startTag) && line.contains("/ month")){
			int first = line.indexOf(startTag);
			value = line.substring(first);
			value = value.replace(startTag, "");
			int last = value.indexOf(closeTag);
			value = value.substring(0, last);
		}
		return value;
	}

}
