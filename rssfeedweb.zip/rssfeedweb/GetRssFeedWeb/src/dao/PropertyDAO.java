package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import model.Property;

public class PropertyDAO {
    public static void addProperty(Property property){
    	Transaction tx = null;
    	Session session = null;
    	SessionFactory factory = null;
        try {
        	Configuration configuration = new Configuration();
            configuration.configure();
            ServiceRegistry  serviceRegistry = new ServiceRegistryBuilder().applySettings(
                    configuration.getProperties()). buildServiceRegistry();
            factory = configuration.buildSessionFactory(serviceRegistry);
        	session = factory.openSession();
        	System.out.println("Connected: " + session.isConnected());
        	tx = session.beginTransaction();
            session.save(property);
            tx.commit();
        } catch (Exception ex) {
        	if (tx!=null){ 
        		tx.rollback();
        	}
        	if (session!=null){ 
        		session.close();
        	}
        	if (factory!=null){ 
        		factory.close();
        	}
            throw ex;
        } finally {
            session.close();
            factory.close();
        }
    } 

}
